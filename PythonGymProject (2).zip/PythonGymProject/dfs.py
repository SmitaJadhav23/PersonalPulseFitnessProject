def dfs(graph, node, visited):
    if node not in visited:
        print(node, end=" ")  # Print the node when visited
        visited.add(node)  # Mark the node as visited
        
        # Recursively visit all unvisited neighbors
        for neighbor in graph[node]:
            dfs(graph, neighbor, visited)

# Example graph represented as an adjacency list
graph = {
    'A': ['B', 'C', 'D'],
    'B': ['E', 'F'],
    'C': ['G'],
    'D': ['H'],
    'E': [],
}

dfs(graph, 'A','C')