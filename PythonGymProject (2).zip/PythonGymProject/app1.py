import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk  # For loading and displaying images
import sqlite3
from PIL import Image, ImageTk
from tkinter import Tk, ttk
from tkinter import PhotoImage  # Import PhotoImage if not already done


root = tk.Tk()  # Initialize the root window


# Database Setup
def setup_database():
    conn = sqlite3.connect("gym_management.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER,
        weight REAL,
        height REAL,
        goal TEXT
    )
    """)
    conn.commit()
    conn.close()

# Main Application Class
class GymManagementSystem:
    def __init__(self, root):

        self.root = root
        self.root.title("Gym Management System")
        self.root.geometry("1000x600")
        self.root.configure(bg="#e0e0e0")

        # Title
        title = tk.Label(root, text="Personal Pulse Fitness", font=("Arial", 28, "bold"), bg="#4CAF50", fg="white")
        title.pack(side=tk.TOP, fill=tk.X, pady=10)

        # Tabs
        tab_control = ttk.Notebook(root)

        self.member_tab = ttk.Frame(tab_control)
        tab_control.add(self.member_tab, text="Manage Members")
        self.create_member_tab()

        self.diet_tab = ttk.Frame(tab_control)
        tab_control.add(self.diet_tab, text="Diet Recommendation")
        self.create_diet_tab()

        self.workout_tab = ttk.Frame(tab_control)
        tab_control.add(self.workout_tab, text="Workout Recommendation")
        self.create_workout_tab()

        tab_control.pack(expand=1, fill="both")

        setup_database()


    # Member Management Tab
    def create_member_tab(self):
        lbl = tk.Label(self.member_tab, text="Member Management", font=("Arial", 20, "bold"), bg="#D3D3D3")
        lbl.pack(pady=15, fill=tk.X)

        main_frame = tk.Frame(self.member_tab, bg="#e0e0e0")
        main_frame.pack(fill=tk.BOTH, expand=True)

        form_frame = tk.Frame(main_frame, bg="#e0e0e0", bd=2, relief=tk.GROOVE)
        form_frame.pack(side=tk.LEFT, pady=20, padx=20, fill=tk.Y, expand=True)

        labels = ["Name:", "Age:", "Weight (kg):", "Height (cm):", "Goal:"]
        self.entries = []

        for i, label_text in enumerate(labels):
            tk.Label(form_frame, text=label_text, font=("Arial", 14), bg="#e0e0e0").grid(row=i, column=0, padx=15, pady=10, sticky="w")
            if label_text == "Goal:":
                entry = ttk.Combobox(form_frame, values=["Lose Weight", "Gain Muscle", "Maintain Fitness"], font=("Arial", 14))
            else:
                entry = tk.Entry(form_frame, font=("Arial", 14))
            entry.grid(row=i, column=1, padx=15, pady=10, sticky="w")
            self.entries.append(entry)

        button_frame = tk.Frame(form_frame, bg="#e0e0e0")
        button_frame.grid(row=len(labels), column=0, columnspan=2, pady=20)

        add_button = ttk.Button(button_frame, text="Add Member", command=self.add_member, style="BlackText.TButton")
        add_button.grid(row=0, column=0, padx=0)
        view_button = ttk.Button(button_frame, text="View Members", command=self.view_members, style="BlackText.TButton")
        view_button.grid(row=0, column=1, padx=20)

        image_frame = tk.Frame(main_frame, bg="#e0e0e0")
        image_frame.pack(side=tk.RIGHT, padx=20, pady=20)

        try:
            img = Image.open("fro1.jpg")
            img = img.resize((500, 700), Image.Resampling.LANCZOS)
            self.image = ImageTk.PhotoImage(img)
            img_label = tk.Label(image_frame, image=self.image, bg="#e0e0e0")
            img_label.pack()
        except FileNotFoundError:
            tk.Label(image_frame, text="Image not found.", font=("Arial", 16), bg="#e0e0e0", fg="red").pack()

    def add_member(self):
        name, age, weight, height, goal = [entry.get() for entry in self.entries]
        if not (name and age and weight and height and goal):
            messagebox.showwarning("Input Error", "All fields are required!")
            return
        if not age.isdigit() or int(age) < 18:
            messagebox.showwarning("Age Validation", "Member must be at least 18 years old!")
            return

        try:
            conn = sqlite3.connect("gym_management.db")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO members (name, age, weight, height, goal) VALUES (?, ?, ?, ?, ?)",
                           (name, int(age), float(weight), float(height), goal))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", f"Member {name} added successfully!")
            for entry in self.entries:
                entry.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")

    def view_members(self):
        conn = sqlite3.connect("gym_management.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM members")
        members = cursor.fetchall()
        conn.close()

        member_list = tk.Toplevel(self.root)
        member_list.title("Members")
        member_list.geometry("700x400")
        member_list.configure(bg="#f0f0f0")

        tree = ttk.Treeview(member_list, columns=("ID", "Name", "Age", "Weight", "Height", "Goal"), show="headings")
        for col in tree["columns"]:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")
        tree.pack(fill=tk.BOTH, expand=True)

        for member in members:
            tree.insert("", tk.END, values=member)

    # Diet Recommendation Tab
    def create_diet_tab(self):
        lbl = tk.Label(self.diet_tab, text="Diet Recommendation", font=("Arial", 20, "bold"), bg="#D3D3D3")
        lbl.pack(pady=15, fill=tk.X)

        tk.Label(self.diet_tab, text="Enter Member's Name:", font=("Arial", 14)).pack(pady=10)
        self.diet_name_entry = tk.Entry(self.diet_tab, font=("Arial", 14))
        self.diet_name_entry.pack(pady=10)
        
        ttk.Button(self.diet_tab, text="Get Diet Plan", command=self.get_diet_plan).pack(pady=5)  # Reduced pady
        self.diet_result_frame = None
        style.configure("Large.TButton", font=("Arial", 30))


    def clear_diet_frame(self):
        if self.diet_result_frame:
            self.diet_result_frame.destroy()

    def get_diet_plan(self):
        name = self.diet_name_entry.get()
        if name:
            conn = sqlite3.connect("gym_management.db")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM members WHERE name=?", (name,))
            member = cursor.fetchone()
            conn.close()

            if member:
                goal = member[5]
                self.clear_diet_frame()

                # Main Frame
                self.diet_result_frame = tk.Frame(self.diet_tab, bg="#ffffff", bd=2, relief=tk.GROOVE)
                self.diet_result_frame.pack(pady=5, fill=tk.BOTH, expand=True)

                diet_plans = {
                    "Lose Weight": [
                        "1. Breakfast: Oatmeal with fruits and nuts",
                        "2. Snack: 1 apple or 1 orange",
                        "3. Lunch: Grilled chicken with quinoa and veggies",
                        "4. Snack: 1 boiled egg or protein shake",
                        "5. Dinner: Baked fish with steamed broccoli"
                    ],
                    "Gain Muscle": [
                        "1. Breakfast: Scrambled eggs with whole grain toast",
                        "2. Snack: Peanut butter and banana smoothie",
                        "3. Lunch: Chicken breast with brown rice and spinach",
                        "4. Snack: Greek yogurt with almonds",
                        "5. Dinner: Steak with sweet potatoes and green beans"
                    ],
                    "Maintain Fitness": [
                        "1. Breakfast: Avocado toast with poached eggs",
                        "2. Snack: Handful of mixed nuts",
                        "3. Lunch: Grilled salmon with mixed greens",
                        "4. Snack: Cottage cheese with berries",
                        "5. Dinner: Roasted turkey with quinoa salad"
                    ]
                }

                # Image paths for each goal
                img_path = {
                    "Lose Weight": "food1.jpg",
                    "Gain Muscle": "food2.jpg",
                    "Maintain Fitness": "food3.jpg"
                }

                # Create the result frame
                self.diet_result_frame = tk.Frame(self.diet_tab, bg="#ffffff", bd=2, relief=tk.GROOVE)
                self.diet_result_frame.pack(pady=20, fill=tk.BOTH, expand=True)

                # Left frame for image
                left_frame = tk.Frame(self.diet_result_frame, bg="#ffffff")
                left_frame.pack(side=tk.LEFT, padx=10)

                # Load and display the image
                try:
                    img = Image.open(img_path[goal])
                    img = img.resize((300, 300), Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(img)
                    tk.Label(left_frame, image=photo, bg="#ffffff").pack(pady=10)
                    self.diet_result_frame.photo = photo  # Keep a reference to avoid garbage collection
                except FileNotFoundError:
                    messagebox.showerror("Image Not Found", f"Image file '{img_path[goal]}' not found.")

                # Right frame for diet recommendations
                right_frame = tk.Frame(self.diet_result_frame, bg="#f2f2f2", relief="groove", bd=2)
                right_frame.pack(side=tk.LEFT, padx=20, fill=tk.BOTH, expand=True)

                # Display the recommendations
                plan_text = diet_plans.get(goal, [])
                for text in plan_text:
                    rec_box = tk.Frame(right_frame, relief="solid", bd=1, bg="#f2f2f2", padx=10, pady=2)
                    rec_box.pack(fill=tk.X, pady=7)
                    rec_label = tk.Label(rec_box, text=text, font=("Arial", 12), bg="#f2f2f2")
                    rec_label.pack()

            else:
                messagebox.showwarning("Member Not Found", "No member found with that name.")
        else:
            messagebox.showwarning("Input Error", "Please enter a member's name.")


    # Workout Recommendation Tab
        # Workout Recommendation Tab
    def create_workout_tab(self):
        lbl = tk.Label(self.workout_tab, text="Workout Recommendation", font=("Arial", 20, "bold"), bg="#D3D3D3")
        lbl.pack(pady=15, fill=tk.X)

        # Input Section
        tk.Label(self.workout_tab, text="Enter Member's Name:", font=("Arial", 14)).pack(pady=10)
        self.workout_name_entry = tk.Entry(self.workout_tab, font=("Arial", 14))
        self.workout_name_entry.pack(pady=10)

        # Button to Get Workout Plan
        ttk.Button(self.workout_tab, text="Get Workout Plan", command=self.get_workout_plan).pack(pady=20)
        self.workout_result_frame = None  # Initialize the result frame

    # Clear Workout Frame
    def clear_workout_frame(self):
        if self.workout_result_frame:
            self.workout_result_frame.destroy()

    # Get Workout Plan
    def get_workout_plan(self):
        name = self.workout_name_entry.get()
        if name:
            conn = sqlite3.connect("gym_management.db")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM members WHERE name=?", (name,))
            member = cursor.fetchone()
            conn.close()

            if member:
                goal = member[5]  # Fetching the user's goal
                self.clear_workout_frame()

                # Recommendations for Workout Plans
                workout_plans = {
                    "Lose Weight": [
                        "1. Cardio: 30 min running/cycling",
                        "2. Strength Training: Squats, lunges, push-ups",
                        "3. Cool-down: 15 min stretching"
                    ],
                    "Gain Muscle": [
                        "1. Heavy Lifts: Deadlifts, bench press, squats",
                        "2. Hypertrophy: 4 sets of 8-12 reps",
                        "3. Rest: Proper recovery with light activity"
                    ],
                    "Maintain Fitness": [
                        "1. Cardio: 20 min cycling",
                        "2. Strength: Bodyweight exercises (push-ups, planks)",
                        "3. Flexibility: 30 min yoga or pilates"
                    ]
                }

                # Workout Images Based on Goals
                img_path = {
                    "Lose Weight": "workout1.jpg",
                    "Gain Muscle": "workout2.jpg",
                    "Maintain Fitness": "workout3.jpg"
                }.get(goal, "image.jpg")

                # Main Result Frame
                self.workout_result_frame = tk.Frame(self.workout_tab, bg="#ffffff", bd=2, relief=tk.GROOVE)
                self.workout_result_frame.pack(pady=10, fill=tk.BOTH, expand=True)

                # Left Side: Image
                left_frame = tk.Frame(self.workout_result_frame, bg="#ffffff", bd=0)
                left_frame.grid(row=0, column=0, padx=20, pady=20)

                try:
                    img = Image.open(img_path)
                    img = img.resize((350, 350), Image.Resampling.LANCZOS)  # Resized image
                    photo = ImageTk.PhotoImage(img)
                    tk.Label(left_frame, image=photo, bg="#ffffff").pack()
                    self.workout_result_frame.photo = photo  # Prevent garbage collection
                except FileNotFoundError:
                    tk.Label(left_frame, text="Image not found.", font=("Arial", 16), bg="#ffffff", fg="red").pack()

                # Right Side: Workout Recommendations
                right_frame = tk.Frame(self.workout_result_frame, bg="#f9f9f9", bd=2, relief=tk.GROOVE)
                right_frame.grid(row=0, column=1, padx=20, pady=10, sticky="nsew")

                tk.Label(right_frame, text=f"Workout Plan: {goal}", font=("Arial", 18, "bold"), bg="#4CAF50", fg="white", pady=10).pack(fill=tk.X)

                for idx, recommendation in enumerate(workout_plans[goal], 1):
                    tk.Label(right_frame, text=recommendation, font=("Arial", 14), bg="#f9f9f9", anchor="w",
                             bd=2, relief=tk.RAISED, padx=10, pady=5).pack(fill=tk.X, padx=10, pady=5)

                self.workout_result_frame.grid_columnconfigure(1, weight=1)
            else:
                messagebox.showwarning("Member Not Found", "No member found with that name.")
        else:
            messagebox.showwarning("Input Error", "Please enter a member's name.")
            
            
            
            # Adding the Enquiry Form Tab
def create_enquiry_form_tab(self):
    lbl = tk.Label(self.enquiry_tab, text="Enquiry Form", font=("Arial", 20, "bold"), bg="#D3D3D3")
    lbl.pack(pady=15, fill=tk.X)

    main_frame = tk.Frame(self.enquiry_tab, bg="#e0e0e0", bd=2, relief=tk.GROOVE)
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

    # Form Fields
    tk.Label(main_frame, text="Name:", font=("Arial", 14), bg="#e0e0e0").grid(row=0, column=0, padx=10, pady=10, sticky="w")
    self.enquiry_name_entry = tk.Entry(main_frame, font=("Arial", 14))
    self.enquiry_name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")

    tk.Label(main_frame, text="Age:", font=("Arial", 14), bg="#e0e0e0").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    self.enquiry_age_entry = tk.Entry(main_frame, font=("Arial", 14))
    self.enquiry_age_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")

    # Health Issues Checkboxes
    self.health_issues = {
        "Diabetes": tk.IntVar(),
        "Blood Pressure": tk.IntVar(),
        "Asthma": tk.IntVar(),
        "Heart Disease": tk.IntVar()
    }

    tk.Label(main_frame, text="Health Issues:", font=("Arial", 14), bg="#e0e0e0").grid(row=2, column=0, padx=10, pady=10, sticky="nw")
    health_frame = tk.Frame(main_frame, bg="#e0e0e0")
    health_frame.grid(row=2, column=1, padx=10, pady=10, sticky="w")

    for idx, (issue, var) in enumerate(self.health_issues.items()):
        tk.Checkbutton(health_frame, text=issue, variable=var, font=("Arial", 12), bg="#e0e0e0").grid(row=idx, column=0, sticky="w")

    # Submit Button
    submit_btn = ttk.Button(main_frame, text="Submit", command=self.submit_enquiry_form)
    submit_btn.grid(row=3, column=0, columnspan=2, pady=20)

def submit_enquiry_form(self):
    name = self.enquiry_name_entry.get()
    age = self.enquiry_age_entry.get()
    issues = [issue for issue, var in self.health_issues.items() if var.get()]

    if not name or not age:
        messagebox.showwarning("Input Error", "Name and Age are required!")
        return

    if not age.isdigit() or int(age) < 0:
        messagebox.showwarning("Input Error", "Please enter a valid age!")
        return

    issue_list = ", ".join(issues) if issues else "None"
    messagebox.showinfo("Enquiry Submitted", f"Name: {name}\nAge: {age}\nHealth Issues: {issue_list}")

    # Clear form entries
    self.enquiry_name_entry.delete(0, tk.END)
    self.enquiry_age_entry.delete(0, tk.END)
    for var in self.health_issues.values():
        var.set(0)
        

# Adding Enquiry Form Tab to the App
tab_control = ttk.Notebook(root)
enquiry_tab = ttk.Frame(tab_control)
tab_control.add(enquiry_tab, text="Enquiry")
tab_control.pack(expand=1, fill="both")



# Main Execution
if __name__ == "__main__":
    root = tk.Tk()

    # Configure Button Style for black text on a white background
    style = ttk.Style()
    style.configure("BlackText.TButton",
                    background="black", foreground="black", font=("Arial", 12),
                    padding=10)
    
    app = GymManagementSystem(root)
    root.mainloop()