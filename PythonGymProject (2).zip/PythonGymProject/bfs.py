from collections import deque

def bfs(graph, start_node):
    visited = set()  # Set to track visited nodes
    queue = deque([start_node])  # Queue for BFS
    visited.add(start_node)
    
    print("BFS Traversal:")
    
    while queue:
        # Dequeue a node from the front of the queue
        node = queue.popleft()
        print(node, end=" ")
        
        # Enqueue all unvisited neighbors
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

# Example graph represented as an adjacency list
graph = {
    'A': ['B', 'C', 'D'],
    'B': ['A', 'E', 'F'],
    'C': ['A', 'G'],
    'D': ['A', 'H'],
    'E': ['B'],
    'F': ['B'],
    'G': ['C'],
    'H': ['D']
}

# Starting BFS traversal from node 'A'
bfs(graph, 'A')